package com.gradpilot.chatbot.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatServiceTest {
    @Test
    void contextLoads() {
        // Add real service tests here as needed.
    }
}