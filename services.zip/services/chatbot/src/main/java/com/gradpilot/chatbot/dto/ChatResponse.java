// src/main/java/com/gradpilot/chatbot/dto/ChatResponse.java
package com.gradpilot.chatbot.dto;

public record ChatResponse(String reply) {}
