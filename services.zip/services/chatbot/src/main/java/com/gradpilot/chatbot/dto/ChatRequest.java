// src/main/java/com/gradpilot/chatbot/dto/ChatRequest.java
package com.gradpilot.chatbot.dto;

public record ChatRequest(String message) {
}
