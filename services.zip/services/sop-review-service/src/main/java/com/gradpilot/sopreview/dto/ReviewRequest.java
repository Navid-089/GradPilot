package com.gradpilot.sopreview.dto;

public record ReviewRequest(String sopText) {}