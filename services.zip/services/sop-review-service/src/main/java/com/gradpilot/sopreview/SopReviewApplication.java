package com.gradpilot.sopreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SopReviewApplication {

    public static void main(String[] args) {
        SpringApplication.run(SopReviewApplication.class, args);
    }
}