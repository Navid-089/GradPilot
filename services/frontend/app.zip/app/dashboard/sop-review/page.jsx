import SopReview from "@/components/sop/sop-review"

export default function SopReviewPage() {
  return <SopReview />
} 